<?php
// Получить список деревьев и кустарников
function getTreesAndShrubs() {
    $stmt = Connection::get()->query('select * from treesandshrubsalldata');
    $result = [];
    while($rows = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
        for ($i = 0; $i < count($rows); $i++) {
            $row = $rows[$i];
            $result[$i] = $row;
        }
    }
    return $result;
}
// Получить список деревьев
function getTrees() {
    $stmt = Connection::get()->query('select * from treesandshrubsalldataonlyfortrees');
    $result = [];
    while($rows = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
        for ($i = 0; $i < count($rows); $i++) {
            $row = $rows[$i];
            $result[$i] = $row;
        }
    }
    return $result;
}
// Получить список кустарников
function getShrubs() {
    $stmt = Connection::get()->query('select * from treesandshrubsalldataonlyforshrubs');
    $result = [];
    while($rows = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
        for ($i = 0; $i < count($rows); $i++) {
            $row = $rows[$i];
            $result[$i] = $row;
        }
    }
    return $result;
}
// Получить список цветников и газонов
function getFlowersAndGardens() {
    $stmt = Connection::get()->query('select * from flowerGardensAllData');
    $result = [];
    while($rows = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
        for ($i = 0; $i < count($rows); $i++) {
            $row = $rows[$i];
            $result[$i] = $row;
        }
    }
    return $result;
}
// Получить список цветников
function getFlowers() {
    $stmt = Connection::get()->query('select * from flowerGardensAllDataOnlyForFlower');
    $result = [];
    while($rows = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
        for ($i = 0; $i < count($rows); $i++) {
            $row = $rows[$i];
            $result[$i] = $row;
        }
    }
    return $result;
}
// Получить список газонов
function getGardens() {
    $stmt = Connection::get()->query('select * from flowerGardensAllDataOnlyForGardens');
    $result = [];
    while($rows = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
        for ($i = 0; $i < count($rows); $i++) {
            $row = $rows[$i];
            $result[$i] = $row;
        }
    }
    return $result;
}
// Получить данные по всем гео-объектам
function getAllObjects() {
    $stmt = Connection::get()->query('SELECT * FROM "mainObjects"');
    $result = [];
    while($rows = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
        for ($i = 0; $i < count($rows); $i++) {
            $row = $rows[$i];
            $result[$i] = $row;
        }
    }
    return $result;
}
// Получить паспорта
function getPassports() {
    $stmt = Connection::get()->query('select * from passportObjectView;');
    $result = [];
    while($rows = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
        for ($i = 0; $i < count($rows); $i++) {
            $row = $rows[$i];
            $result[$i] = $row;
        }
    }
    return $result;
}
// Получить координаты объекта по его ID
function getCoordinatesById($id) {
    $stmt = Connection::get()->query('select "latitude ", longitude from "treesAndShrubs" where "treesAndShrubsId" = '.$id);
    $result = [];
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $result = $row;
    }
    return $result;
}
// Получить данные дерева по его ID
function getTreeInfo($id) {
    $stmt = Connection::get()->query('select * from treesAndShrubsAllData where "treesAndShrubsId" = '.$id);
    $result = [];
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $result = $row;
    }
    return $result;
}
// Получить неполные данные для маркеров деревьев
function getTreesMarkers() {
    $stmt = Connection::get()->query('select * from treesAndShrubsalldata;');
    $result = [];
    while($rows = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
        for ($i = 0; $i < count($rows); $i++) {
            $row = $rows[$i];
            $result[$i] = $row;
        }
    }
    return $result;
}
// Получить данные о всех участках по айди объекта
function getAllAreasByObjectId($objectId) {
    $stmt = Connection::get()->query("select * from treesAndShrubsDataSiteNumbersWithMainObjectId($objectId);");
    $result = [];
    while($rows = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
        for ($i = 0; $i < count($rows); $i++) {
            $row = $rows[$i];
            $result[$i] = $row;
        }
    }
    return $result;
}
// Запрос всех деревьев и кустарников по айди объекта и номеру участка
function getTreesAndShrubsByAreaId($objectId, $areaNumber) {
    $stmt = Connection::get()->query("select * from treesAndShrubsAllDataForSiteNumberAndMainObjectId($objectId, $areaNumber);");
    $result = [];
    while($rows = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
        for ($i = 0; $i < count($rows); $i++) {
            $row = $rows[$i];
            $result[$i] = $row;
        }
    }
    return $result;
}  
// Получить отфильтрованные деревья
function getFilteredTrees($filters) {
    $sql = constructFilterQueryForTrees($filters);
    writeToServerLog($sql);
    $stmt = Connection::get()->query($sql);
    $result = [];
    while($rows = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
        for ($i = 0; $i < count($rows); $i++) {
            $row = $rows[$i];
            $result[$i] = $row;
        }
    }
    
    return $result;
}
