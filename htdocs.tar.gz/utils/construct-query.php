<?php
function constructFilterQueryForTrees($filters) {
    $sql = 'select * from "treesandshrubsalldata" where "treesAndShrubsId" in (select "treesAndShrubsId" from "treesAndShrubs" where 1 = 1 ';
    
    writeToServerLog(json_encode($filters));

    // Фильтр по  текущему возрасту
    $age_from = $filters['currentAge_from'];
    $age_to = $filters['currentAge_to'];

    if(strlen($age_from) > 0) {
        if(strlen($age_to) > 0) {
            $sql = $sql.'"currentAge" between '.$age_from.' and '.$age_to.' ';
        } else {
            $sql = $sql.'"currentAge" >= '.$age_from.' ';
        }
    } 
    else if(strlen($age_to) > 0) {
        if(strlen($age_from) > 0) {
            $sql = $sql.'"currentAge" between '.$age_from.' and '.$age_to.' ';
        } else {
            $sql = $sql.'"currentAge" <= '.$age_to.' ';
        }
    }

    // Фильтр по возрасту посадки
    $landingAge_from = $filters['landingAge_from'];
    $landingAge_to = $filters['landingAge_to'];

    if(strlen($landingAge_from) > 0) {
        $sql = $sql.'and ';
        if(strlen($landingAge_to) > 0) {
            $sql = $sql.'"landingAge" between '.$landingAge_from.' and '.$landingAge_to.' ';
        } else {
            $sql = $sql.'"landingAge" >= '.$landingAge_from.' ';
        }
    } 
    else if(strlen($landingAge_to) > 0) {
        $sql = $sql.'and ';
        if(strlen($landingAge_from) > 0) {
            $sql = $sql.'"landingAge" between '.$landingAge_from.' and '.$landingAge_to.' ';
        } else {
            $sql = $sql.'"landingAge" <= '.$landingAge_to.' ';
        }
    }

    // Фильтр по высоте
    $heigth_from = $filters['heig_from'];
    $heigth_to = $filters['heig_to'];

    if(strlen($heigth_from) > 0) {
        $sql = $sql.'and ';
        if(strlen($heigth_to) > 0) {
            $sql = $sql.'"height" between '.$heigth_from.' and '.$heigth_to.' ';
        } else {
            $sql = $sql.'"height" >= '.$heigth_from.' ';
        }
    } 
    else if(strlen($heigth_to) > 0) {
        $sql = $sql.'and ';
        if(strlen($heigth_from) > 0) {
            $sql = $sql.'"height" between '.$heigth_from.' and '.$heigth_to.' ';
        } else {
            $sql = $sql.'"height" <= '.$heigth_to.' ';
        }
    }

    // Фильтр по диаметру
    $diametr_from = $filters['diameterAtHeight13_from'];
    $diametr_to = $filters['diameterAtHeight13_to'];

    if(strlen($diametr_from) > 0) {
        $sql = $sql.'and ';
        if(strlen($diametr_to) > 0) {
            $sql = $sql.'"diameterAtHeight13" between '.$diametr_from.' and '.$diametr_to.' ';
        } else {
            $sql = $sql.'"diameterAtHeight13" >= '.$diametr_from.' ';
        }
    } 
    else if(strlen($diametr_to) > 0) {
        $sql = $sql.'and ';
        if(strlen($diametr_from) > 0) {
            $sql = $sql.'"diameterAtHeight13" between '.$diametr_from.' and '.$diametr_to.' ';
        } else {
            $sql = $sql.'"diameterAtHeight13" <= '.$diametr_to.' ';
        }
    }

    // Фильтр по дате посадки
    $landing_from = $filters['landingDate_from'];
    $landing_to = $filters['landingDate_to'];

    if(strlen($landing_from) > 0) {
        $sql = $sql.'and ';
        if(strlen($landing_to) > 0) {
            $sql = $sql.'"landingDate" between TO_DATE('."'".$landing_from."', 'DD/MM/YYYY') AND TO_DATE('".$landing_to."', 'DD/MM/YYYY') ";
        } else {
            $sql = $sql.'"landingDate" >= TO_DATE('."'".$landing_from."', 'DD/MM/YYYY') ";
        }
    } 
    else if(strlen($landing_to) > 0) {
        $sql = $sql.'and ';
        if(strlen($landing_from) > 0) {
            $sql = $sql.'"landingDate" between TO_DATE('."'".$landing_from."', 'DD/MM/YYYY') AND TO_DATE('".$landing_to."', 'DD/MM/YYYY') ";
        } else {
            $sql = $sql.'"landingDate" <= TO_DATE('."'".$landing_to."', 'DD/MM/YYYY') ";
        }
    }

    // Фильтр по дате изобретения
    $invent_from = $filters['inventDate_from'];
    $invent_to = $filters['inventDate_to'];

    if(strlen($invent_from) > 0) {
        $sql = $sql.'and ';
        if(strlen($invent_to) > 0) {
            $sql = $sql.'"inventDate" between TO_DATE('."'".$invent_from."', 'DD/MM/YYYY') AND TO_DATE('".$invent_to."', 'DD/MM/YYYY') ";
        } else {
            $sql = $sql.'"inventDate" >= TO_DATE('."'".$invent_from."', 'DD/MM/YYYY') ";
        }
    } 
    else if(strlen($invent_to) > 0) {
        $sql = $sql.'and ';
        if(strlen($invent_from) > 0) {
            $sql = $sql.'"inventDate" between TO_DATE('."'".$invent_from."', 'DD/MM/YYYY') AND TO_DATE('".$invent_to."', 'DD/MM/YYYY') ";
        } else {
            $sql = $sql.'"inventDate" <= TO_DATE('."'".$invent_to."', 'DD/MM/YYYY') ";
        }
    }

    // Фильтр по породам
    $species = $filters['specieId'];
    if(count($species) > 0) {
        $sql = $sql.'and "specieId" in (';
        foreach ($species as $value) {
            $sql = $sql."'".$value."',";
        }
        $sql = substr($sql, 0, -1);
        $sql = $sql.') ';
    }

    // Фильтр по рекомендацям
    $recommend = $filters['recommend'];
    if(count($recommend) > 0) {
        $sql = $sql.'and "recommendationId" in (';
        foreach ($recommend as $value) {
            $sql = $sql."'".$value."',";
        }
        $sql = substr($sql, 0, -1);
        $sql = $sql.') ';
    }

    // Фильтр по номеру участка
    $siteNumber = $filters['siteNumber'];
    if(count($siteNumber) > 0) {
        $sql = $sql.'and "siteNumber" in (';
        foreach ($siteNumber as $value) {
            $sql = $sql."'".$value."',";
        }
        $sql = substr($sql, 0, -1);
        $sql = $sql.') ';
    }

    // Фильтр по главному объекту
    $mainObjectId = $filters['mainObjectId'];
    if(count($mainObjectId) > 0) {
        $sql = $sql.'and "mainObjectId" in (';
        foreach ($mainObjectId as $value) {
            $sql = $sql."'".$value."',";
        }
        $sql = substr($sql, 0, -1);
        $sql = $sql.') ';
    }

    // Фильтр по типам насаждений
    $types = $filters['plantingType'];
    if(count($types) > 0) {
        $sql = $sql.'and "plantingType" in (';
        foreach ($types as $value) {
            $sql = $sql."'".$value."',";
        }
        $sql = substr($sql, 0, -1);
        $sql = $sql.') ';
    }

    // Фильтр по жизненному состоянию
    $statuses = $filters['treeOrShrubLifeStatusCategoryId'];
    if(count($statuses) > 0) {
        $sql = $sql.'and "treeOrShrubLifeStatusCategoryId" in (';
        foreach ($statuses as $value) {
            $sql = $sql."'".$value."',";
        }
        $sql = substr($sql, 0, -1);
        $sql = $sql.') ';
    }

    // Фильтр по жизненным формам
    $forms = $filters['lifeFormId'];
    if(count($forms) > 0) {
        $sql = $sql.'and "lifeFormId" in (';
        foreach ($forms as $value) {
            $sql = $sql."'".$value."',";
        }
        $sql = substr($sql, 0, -1);
        $sql = $sql.') ';
    }

    $sql = $sql.")";

    return $sql;
}