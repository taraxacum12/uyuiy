<?php
// Загрузка файлов на сервер
function upload() {
    $uploaddir = 'uploads/';
    $uploadfile = $uploaddir . basename($_FILES['userfile']['name']);
    move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile);
    return $_FILES['userfile']['name'];
}
function uploadTreeImage() {
    $uploaddir = 'uploads/';
    $uploadfile = $uploaddir . basename($_FILES['userfile']['name']);
    move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile);
    return $_FILES['userfile']['name'];
}
function uploadLeafImage() {
    $uploaddir = 'uploads/';
    $uploadfile = $uploaddir . basename($_FILES['leafimg']['name']);
    move_uploaded_file($_FILES['leafimg']['tmp_name'], $uploadfile);
    return $_FILES['leafimg']['name'];
}
?>