<?php

// Роутер для справочной информации
function route($method, $urlData, $formData) {
    header('Content-Type: application/json');

    // Получение информации о деревьях
    // GET /map/trees
    if ($method === 'GET' && count($urlData) === 1 && $urlData[0] === "trees") {
        $result = getTreesMarkers();
        echo json_encode($result);
        return;
    }

    // Получение информации о деревe
    // GET /map/tree/id
    if ($method === 'GET' && count($urlData) === 2 && $urlData[0] === "tree") {
        $result = getTreeInfo($urlData[1]);
        echo json_encode($result);
        return;
    }

    // Получить данные о всех участках по айди объекта
    // GET /map/sites/{objectId}
    if ($method === 'GET' && count($urlData) === 2 && $urlData[0] === "sites") {
        $result = getAllAreasByObjectId($urlData[1]);
        echo json_encode($result);
        return;
    }

    // Запрос всех деревьев и кустарников по айди объекта и номеру участка
    // GET /map/trees/object/{objectId}/site/{siteNumber}
    if ($method === 'GET' && count($urlData) === 5 && $urlData[0] === "trees" && $urlData[1] === "object" && $urlData[3] === "site") {
        $result = getTreesAndShrubsByAreaId($urlData[2], $urlData[4]);
        echo json_encode($result);
        return;
    }

    // Отфильтрованные деревья
    // POST /map/tree/filter
    if ($method === 'POST' && count($urlData) === 2 && $urlData[0] === "tree" && $urlData[1] === "filter") {
        $result = getFilteredTrees($formData);
        echo json_encode($result);
        return;
    }

    // Возвращаем ошибку
    header('HTTP/1.0 400 Bad Request');
    echo json_encode(array(
        'error' => 'У нас нет такого запроса. Проверьте УРЛ.'
    ));
}
